<?php


namespace frontend\controllers;


use common\models\Video;
use common\models\VideoLike;
use common\models\VideoView;
use yii\data\ActiveDataProvider;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\web\NotFoundHttpException;

class VideoController extends Controller
{
    public function behaviors()
    {
        return [
            'access'=>[
                'class'=>AccessControl::class,
                'only'=>['like', 'dislike', 'history'],
                'rules'=>[
                    [
                        'allow'=>true,
                        'roles'=>['@']
                    ]
                ],
            ],
        ];
    }

    public function actionIndex()
    {
        $dataProvider = new ActiveDataProvider([
            'query'=> Video::find()->with('createdBy')->published()->latest()
        ]);
        return $this->render('index', [
            'dataProvider'=>$dataProvider,
            'pagination' => [
                'pageSize' => 6
            ]
        ]);
    }

    public function actionHistory(){
        $query = Video::find()
            ->alias('v')
            ->innerJoin("(Select video_id, MAX(created_at) as max_date FROM video_view WHERE user_id = :userId GROUP BY video_id) vv", 'vv.video_id=v.video_id', [
                'userId'=>\Yii::$app->user->id
            ])
            ->orderBy('vv.max_date DESC');

        $dataProvider = new ActiveDataProvider([
            'query'=> $query
        ]);
        return $this->render('history', [
            'dataProvider'=>$dataProvider
        ]);
    }

    public function actionView($id){
        $this->layout = 'auth';
        $video = $this->findVideo($id);
        $videoView = new VideoView();
        $videoView->video_id = $id;
        $videoView->user_id = \Yii::$app->user->id;
        $videoView->created_at = time();
        $videoView->save();
        $similarVideo = Video::find()
            ->published()
            ->andWhere(['NOT', ['video_id'=>$id]])
            ->byKeyword($video->title)
            ->limit(10)
            ->all();
        return $this->render('view', [
            'model'=>$video,
            'similarVideos'=>$similarVideo
        ]);
    }

    public function actionLike($id)
    {
        $video = $this->findVideo($id);
        $userId = \Yii::$app->user->id;
        $videoLike = VideoLike::find()->userIdVideoId($userId, $id)->one();
        if (!$videoLike){
            $this->saveLikeDislike($id, $userId, VideoLike::TYPE_LIKE);
        }else if($videoLike->type == VideoLike::TYPE_LIKE){
            $videoLike->delete();
        }else{
            $videoLike->delete();
            $this->saveLikeDislike($id, $userId, VideoLike::TYPE_LIKE);
        }

        return $this->renderAjax('_buttons', [
            'model'=>$video
        ]);

    }

    public function actionDislike($id)
    {
        $video = $this->findVideo($id);
        $userId = \Yii::$app->user->id;
        $videoLike = VideoLike::find()->userIdVideoId($userId, $id)->one();
        if (!$videoLike){
            $this->saveLikeDislike($id, $userId, VideoLike::TYPE_DISLIKE);
        }else if($videoLike->type == VideoLike::TYPE_DISLIKE){
            $videoLike->delete();
        }else{
            $videoLike->delete();
            $this->saveLikeDislike($id, $userId, VideoLike::TYPE_DISLIKE);

        }

        return $this->renderAjax('_buttons', [
            'model'=>$video
        ]);

    }

    public function actionSearch($keyword)
    {
        $query = Video::find()->published()->latest();
        if ($keyword){
            $query->byKeyword($keyword);
        }
        $dataProvider = new ActiveDataProvider([
            'query'=> $query
        ]);
        return $this->render('search', [
            'dataProvider'=>$dataProvider
        ]);
    }

    protected function findVideo($id){
        $video = Video::findOne($id);
        if (!$video){
            throw new NotFoundHttpException('Video does not exist');
        }
        return $video;
    }

    protected function saveLikeDislike($videoID, $userID, $type)
    {
        $videoLike = new VideoLike();
        $videoLike->video_id = $videoID;
        $videoLike->type = $type;
        $videoLike->user_id = $userID;
        $videoLike->created_at = time();
        $videoLike->save();
    }
}