<?php
/**
 * @var $channel \common\models\User
 * @var $user \common\models\User
 */
?>
Hello <?php echo $channel->username?>
User <?php echo $user->username?>
Tuitcoder
