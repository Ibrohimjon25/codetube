<?php
return [
    'frontendUrl'=>'@frontend/web/'
];
