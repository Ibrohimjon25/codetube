<?php
return [
    'components' => [
        'db' => [
            'class' => 'yii\db\Connection',
            'dsn' => 'mysql:host=localhost;dbname=freecodetube',
            'username' => 'root',
            'password' => 'Beshkapa_city2020',
            'charset' => 'utf8',
        ],
        'mailer' => [
            'class' => 'yii\swiftmailer\Mailer',
            'viewPath' => '@common/mail',
            'transport' => [
                'class' => 'Swift_SmtpTransport',
                'host' => 'smtp.mailtrap.io',
                'username' => '8237bce63559dd',
                'password' => 'b654f956c3973c',
                'port' => '2525',
                'encryption' => 'tls',
            ],
        ],
    ],
];
